//
//  KeycapTests.swift
//  KeycapTests
//
//  Created by Jeremie Lim on 9/2/25.
//

import Testing
@testable import Keycap

struct KeycapTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
