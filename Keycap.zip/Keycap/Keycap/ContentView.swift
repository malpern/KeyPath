//
//  ContentView.swift
//  Keycap
//
//  Created by Jeremie Lim on 9/2/25.
//

import AVFoundation
import Combine
import RealityKit
import SwiftUI

struct ContentView: View {
    @State private var model: ModelEntity?
    private let keyCapText = "M"
    private let keyCaptTextMaterialColor = UIColor.yellow
    private let keyCapMaterialColor = UIColor.purple

    var body: some View {
        ZStack {
            RealityView { content in
                do {
                    let model = try await ModelEntity(named: "keycap")

                    if let keycapEntity = model.findEntity(named: "root") as? ModelEntity {
                        let redMaterial = SimpleMaterial(color: keyCapMaterialColor, isMetallic: false)
                        keycapEntity.model?.materials = [redMaterial]
                    }

                    model.scale = .one * 30
                    model.transform.rotation = simd_quatf(angle: -.pi / 4, axis: SIMD3<Float>(1, 0, 0))
                    model.generateCollisionShapes(recursive: true)
                    model.components.set(InputTargetComponent())

                    let mesh = MeshResource.generateText(keyCapText, extrusionDepth: 0.004, font: .systemFont(ofSize: 0.01))
                    let material = SimpleMaterial(color: keyCaptTextMaterialColor, isMetallic: false)
                    let textEntity = ModelEntity(mesh: mesh, materials: [material])
                    textEntity.position = SIMD3<Float>(-0.0035, -0.006, 0.008)
                    model.addChild(textEntity)

                    DispatchQueue.main.async {
                        self.model = model
                    }
                    content.add(model)
                } catch {
                    print("Failed to load model: \(error)")
                }
            }
            .simultaneousGesture(LongPressGesture(minimumDuration: 0.01).onChanged { _ in
                print("pressed")
                playKeySound()
                if let model = model {
                    var targetTransform = model.transform
                    targetTransform.translation.y = -0.5
                    model.move(to: targetTransform, relativeTo: model.parent, duration: 0.2)
                }
            }.onEnded { _ in
                if let model = model {
                    var targetTransform = model.transform
                    targetTransform.translation.y = 0
                    model.move(to: targetTransform, relativeTo: model.parent, duration: 0.2)
                }
            })
        }
    }

    private func playKeySound() {
        guard let url = Bundle.main.url(forResource: "fxKey", withExtension: "mp3") else {
            print("Sound file not found")
            return
        }
        do {
            let audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer.play()
        } catch {
            print("Failed to play sound: \(error)")
        }
    }

    private func printEntityNames(_ entity: Entity, indent: String = "") {
        print("\(indent)- \(entity.name)")
        for child in entity.children {
            printEntityNames(child, indent: indent + "  ")
        }
    }
}

#Preview {
    ContentView()
}
