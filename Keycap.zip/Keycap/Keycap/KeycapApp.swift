//
//  KeycapApp.swift
//  Keycap
//
//  Created by Jeremie Lim on 9/2/25.
//

import SwiftUI

@main
struct KeycapApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
